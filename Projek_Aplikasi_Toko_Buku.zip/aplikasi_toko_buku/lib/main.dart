import 'package:flutter/material.dart';
import 'pages/welcome/welcome_page.dart';
import 'pages/login/login_page.dart';
import 'pages/registrasi/registrasi_page.dart';
import 'pages/beranda/beranda_page.dart';
import 'pages/keranjang/keranjang_page.dart';
import 'pages/main_page.dart';

// Notifier untuk dark mode dan keranjang
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);
final ValueNotifier<int> cartCountNotifier = ValueNotifier<int>(0);

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, currentMode, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Pustaka Digital',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            brightness: Brightness.light,
          ),
          darkTheme: ThemeData.dark(),
          themeMode: currentMode,
          onGenerateRoute: (settings) {
            switch (settings.name) {
              case '/':
                return MaterialPageRoute(builder: (_) => const WelcomePage());

              case '/login':
                return MaterialPageRoute(builder: (_) => const LoginPage());

              case '/register':
                return MaterialPageRoute(builder: (_) => const RegisterPage());

              case '/beranda':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => BerandaPage(
                    cartNotifier: cartCountNotifier,
                    userData: args['userData'], // ✅ Dikirim ke Beranda
                  ),
                );

              case '/keranjang':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => KeranjangPage(
                    userData: args['userData'], // ✅ Dikirim ke Keranjang
                  ),
                );

              case '/main':
                final args = settings.arguments as Map<String, dynamic>? ?? {};
                return MaterialPageRoute(
                  builder: (_) => MainPage(
                    defaultIndex: args['defaultIndex'] ?? 0,
                    orderData: args['orderData'],
                    userData: args['userData'], // ✅ Dikirim ke MainPage
                  ),
                );

              default:
                return MaterialPageRoute(
                  builder: (_) => const Scaffold(
                    body: Center(child: Text('Halaman tidak ditemukan')),
                  ),
                );
            }
          },
        );
      },
    );
  }
}
