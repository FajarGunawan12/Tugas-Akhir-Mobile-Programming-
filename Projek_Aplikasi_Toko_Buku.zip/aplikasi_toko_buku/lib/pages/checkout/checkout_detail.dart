import 'package:flutter/material.dart';
import '../main_page.dart';

class PaymentSuccessPage extends StatelessWidget {
  final Map<String, dynamic> newOrder;
  final Map<String, dynamic> userData; // ✅ Tambahkan ini

  const PaymentSuccessPage({
    super.key,
    required this.newOrder,
    required this.userData, // ✅ Tambahkan ini juga
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Pembayaran Sukses'),
        backgroundColor: Colors.blue[900],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle, color: Colors.green, size: 100),
              const SizedBox(height: 20),
              const Text(
                'Pembayaran Berhasil!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(
                'Total: Rp ${newOrder['total']}',
                style: const TextStyle(fontSize: 18),
              ),
              Text(
                'Metode: ${newOrder['metode']}',
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MainPage(
                        defaultIndex: 1,
                        orderData: newOrder,
                        userData: userData, // ✅ Kirim ke MainPage
                      ),
                    ),
                    (route) => false,
                  );
                },
                icon: const Icon(Icons.list_alt,color: Colors.white,),
                label: const Text(
                  'Lihat Daftar Pesanan',
                  style: TextStyle(
                    color: Colors.white, // Ganti warna teks di sini
                    fontWeight: FontWeight.bold, // (opsional) bikin teks tebal
                  ),
                ),
                style: ElevatedButton.styleFrom(  
                  backgroundColor: Colors.blue[900],
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
