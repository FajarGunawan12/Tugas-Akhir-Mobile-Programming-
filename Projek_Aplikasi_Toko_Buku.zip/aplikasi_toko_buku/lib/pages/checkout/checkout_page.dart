import 'package:flutter/material.dart';
import 'checkout_detail.dart';
import '../keranjang/keranjang_data.dart';

class CheckoutPage extends StatefulWidget {
  final int totalBayar;
  final List<Map<String, dynamic>> items;
  final Map<String, dynamic> userData; // ✅ Tambahkan ini

  const CheckoutPage({
    super.key,
    required this.totalBayar,
    required this.items,
    required this.userData, // ✅ Tambahkan ini
  });

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String _metodePembayaran = 'Transfer Bank';

  final List<String> metodePembayaranList = [
    'Transfer Bank',
    'OVO',
    'GoPay',
    'DANA',
    'COD (Bayar di Tempat)',
  ];

  void _prosesPembayaran() {
    final orderData = {
      'metode': _metodePembayaran,
      'total': widget.totalBayar,
      'items': widget.items,
    };

    keranjang.clear(); // Kosongkan keranjang setelah pembayaran

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Pembayaran berhasil!'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );

    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => PaymentSuccessPage(
            newOrder: orderData,
            userData: widget.userData, // ✅ Gunakan widget.userData
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout'),
        backgroundColor: Colors.blue[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Buku yang Dibeli', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            // Menampilkan daftar judul buku yang dibeli
            ...widget.items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                '- ${item['judul']} (${item['jumlah']})',
                style: const TextStyle(fontSize: 16),
              ),
            )),

            const SizedBox(height: 20),
            const Text('Metode Pembayaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _metodePembayaran,
              items: metodePembayaranList.map((metode) {
                return DropdownMenuItem<String>(
                  value: metode,
                  child: Text(metode),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _metodePembayaran = value!;
                });
              },
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 20),
            const Text('Total Pembayaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              'Rp ${widget.totalBayar}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _prosesPembayaran,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.blue[900],
                ),
                child: const Text('Bayar Sekarang', style: TextStyle(fontSize: 16,color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
