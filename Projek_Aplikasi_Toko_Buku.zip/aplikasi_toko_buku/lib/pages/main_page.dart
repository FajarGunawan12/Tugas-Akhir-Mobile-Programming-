import 'package:flutter/material.dart';
import 'order/order_data.dart';
import '../pages/beranda/beranda_page.dart';
import 'order/order_page.dart';
import 'profile/profile_page.dart';
import 'wishlist/wishlist_page.dart';

class MainPage extends StatefulWidget {
  final int defaultIndex;
  final Map<String, dynamic>? orderData;
  final Map<String, dynamic>? userData; // ✅ Tambahan: user data dari registrasi

  const MainPage({
    super.key,
    this.defaultIndex = 0,
    this.orderData,
    this.userData,
  });

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late int pageIndex;
  final ValueNotifier<int> cartNotifier = ValueNotifier<int>(0);

  @override
  void initState() {
    super.initState();
    pageIndex = widget.defaultIndex;

    // ✅ Tambahkan order baru ke riwayat
    if (widget.orderData != null) {
      orderHistory.add(widget.orderData!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pageList = [
      BerandaPage(cartNotifier: cartNotifier, userData: widget.userData ?? {},),
      OrderPage(orders: orderHistory),
      const WishlistPage(),
      ProfilPage( // ✅ Kirim nama dan email ke ProfilPage
        nama: widget.userData?['nama'] ?? 'Guest',
        email: widget.userData?['email'] ?? 'guest@email.com',
      ),
    ];

    return Scaffold(
      body: pageList[pageIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: pageIndex,
        onTap: (index) {
          setState(() {
            pageIndex = index;
          });
        },
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: [
          barItem(Icons.home, "Beranda"),
          barItem(Icons.wallet, "Order"),
          barItem(Icons.favorite, "Wishlist"),
          barItem(Icons.account_circle_outlined, "Profil"),
        ],
      ),
    );
  }

  BottomNavigationBarItem barItem(IconData iconData, String title) {
    return BottomNavigationBarItem(
      icon: Icon(iconData),
      label: title,
    );
  }
}
