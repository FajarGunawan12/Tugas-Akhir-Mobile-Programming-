import 'package:flutter/material.dart';
import 'wishlist_data.dart'; // Pastikan item berisi semua data detail buku
import '../beranda/detail_buku_page.dart';

class WishlistPage extends StatefulWidget {
  const WishlistPage({super.key});

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wishlist"),
        backgroundColor: Colors.blue[900],
      ),
      body: wishlist.isEmpty
          ? const Center(
              child: Text(
                "Wishlist kosong",
                style: TextStyle(fontSize: 20, color: Colors.grey),
              ),
            )
          : ListView.builder(
              itemCount: wishlist.length,
              itemBuilder: (context, index) {
                final item = wishlist[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DetailBukuPage(
                            judul: item['judul'],
                            harga: item['harga'],
                            foto: item['foto'],
                            penulis: item['penulis'],
                            deskripsi: item['deskripsi'],
                            kategori: item['kategori'],
                            onAddToCart: () {}, // ← Tambahan ini untuk mencegah error
                          ),
                        ),
                      );
                    },
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset(
                        item['foto'],
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Container(
                          width: 50,
                          height: 50,
                          color: Colors.grey[300],
                          child: const Icon(Icons.broken_image, color: Colors.grey),
                        ),
                      ),
                    ),
                    title: Text(item['judul']),
                    subtitle: Text(
                      "Rp ${item['harga'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (match) => '${match[1]}.')}",
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        setState(() {
                          wishlist.removeAt(index);
                        });

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Buku "${item['judul']}" dihapus dari wishlist.')),
                        );
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}
