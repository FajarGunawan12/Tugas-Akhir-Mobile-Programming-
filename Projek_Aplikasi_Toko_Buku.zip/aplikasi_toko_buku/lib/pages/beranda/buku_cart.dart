import 'package:flutter/material.dart';
import '../keranjang/keranjang_data.dart';
import './detail_buku_page.dart';

class BukuCart extends StatelessWidget {
  final String judul;
  final int harga;
  final String foto;
  final String penulis;
  final String deskripsi;
  final String kategori;
  final VoidCallback onAddToCart;

  const BukuCart({
    super.key,
    required this.judul,
    required this.harga,
    required this.foto,
    required this.penulis,
    required this.deskripsi,
    required this.kategori,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 160,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetailBukuPage(
                judul: judul,
                harga: harga,
                foto: foto,
                penulis: penulis,
                deskripsi: deskripsi,
                kategori: kategori,
                onAddToCart: onAddToCart, // <- Penting untuk badge update
              ),
            ),
          );
        },
        child: Card(
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    foto,
                    height: 120,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 120,
                      color: Colors.grey[300],
                      child: const Center(
                        child: Icon(Icons.broken_image, size: 40, color: Colors.grey),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  judul,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'by $penulis',
                  style: const TextStyle(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'Rp ${harga.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (match) => '${match[1]}.')}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Align(
                  alignment: Alignment.bottomRight,
                  child: IconButton(
                    icon: const Icon(Icons.add_shopping_cart),
                    onPressed: () {
                      final index = keranjang.indexWhere((item) => item['judul'] == judul);
                      if (index != -1) {
                        keranjang[index]['jumlah'] += 1;
                      } else {
                        keranjang.add({
                          'judul': judul,
                          'harga': harga,
                          'foto': foto,
                          'jumlah': 1,
                        });
                      }

                      onAddToCart(); // <- Memicu badge update

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Ditambahkan ke keranjang')),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
