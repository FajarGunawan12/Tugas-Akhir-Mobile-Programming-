final List<Map<String, dynamic>> bukuList = [
  // 📚 Novel
  {
    'judul': 'Laskar Pelangi',
    'penulis': 'Andrea Hirata',
    'harga': 75000,
    'foto': 'assets/img/der.jpg',
    'deskripsi': 'Kisah inspiratif anak-anak Belitung dalam meraih mimpi.',
    'kategori': 'Novel',
  },
  {
    'judul': 'Bumi',
    'penulis': 'Tere Liye',
    'harga': 68000,
    'foto': 'assets/img/bumi.jpg',
    'deskripsi': 'Petualangan seru anak remaja dengan kekuatan istimewa.',
    'kategori': 'Novel',
  },

  // 🎨 Komik
  {
    'judul': 'One Piece Vol. 1',
    'penulis': 'Eiichiro Oda',
    'harga': 35000,
    'foto': 'assets/img/one piece.jpg',
    'deskripsi': 'Petualangan bajak laut Luffy mencari harta karun legendaris.',
    'kategori': 'Komik',
  },
  {
    'judul': 'Naruto Vol. 1',
    'penulis': 'Masashi Kishimoto',
    'harga': 33000,
    'foto': 'assets/img/naruto.jpg',
    'deskripsi': 'Kisah ninja muda yang bercita-cita menjadi Hokage.',
    'kategori': 'Komik',
  },

  // 💻 Teknologi
  {
    'judul': 'Flutter Dasar',
    'penulis': 'Andi Setiawan',
    'harga': 85000,
    'foto': 'assets/img/flutter.jpg',
    'deskripsi': 'Buku ini menjelaskan dasar-dasar pengembangan aplikasi Flutter.',
    'kategori': 'Teknologi',
  },
  {
    'judul': 'Laravel untuk Pemula',
    'penulis': 'Rina Anggraini',
    'harga': 99000,
    'foto': 'assets/img/laravel.jpg',
    'deskripsi': 'Panduan lengkap belajar Laravel dari nol.',
    'kategori': 'Teknologi',
  },

  // 💼 Bisnis
  {
    'judul': 'Rich Dad Poor Dad',
    'penulis': 'Robert Kiyosaki',
    'harga': 79000,
    'foto': 'assets/img/rich.jpg',
    'deskripsi': 'Pelajaran penting tentang kebebasan finansial dan investasi.',
    'kategori': 'Bisnis',
  },
  {
    'judul': 'The Lean Startup',
    'penulis': 'Eric Ries',
    'harga': 82000,
    'foto': 'assets/img/the.jpg',
    'deskripsi': 'Strategi membangun bisnis startup yang efisien dan inovatif.',
    'kategori': 'Bisnis',
  },

  // 👶 Anak-anak
  {
    'judul': 'Dongeng Nusantara',
    'penulis': 'Sari Wulandari',
    'harga': 42000,
    'foto': 'assets/img/dongeng.jpg',
    'deskripsi': 'Kumpulan dongeng klasik dari berbagai daerah di Indonesia.',
    'kategori': 'Anak-anak',
  },
  {
    'judul': 'Mengenal Huruf',
    'penulis': 'Bunda Nisa',
    'harga': 30000,
    'foto': 'assets/img/mengenal.jpg',
    'deskripsi': 'Buku edukatif untuk anak-anak mengenal huruf abjad.',
    'kategori': 'Anak-anak',
  },
];
