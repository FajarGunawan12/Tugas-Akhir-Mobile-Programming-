import 'package:flutter/material.dart';
import '../keranjang/keranjang_data.dart';
import '../wishlist/wishlist_data.dart';

class DetailBukuPage extends StatelessWidget {
  final String judul;
  final int harga;
  final String foto;
  final String penulis;
  final String deskripsi;
  final String kategori;
  final VoidCallback onAddToCart;

  const DetailBukuPage({
    super.key,
    required this.judul,
    required this.harga,
    required this.foto,
    required this.penulis,
    required this.deskripsi,
    required this.kategori,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(judul),
        backgroundColor: Colors.blue[900],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  foto,
                  height: 220,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    height: 220,
                    color: Colors.grey[300],
                    child: const Icon(Icons.broken_image, size: 60, color: Colors.grey),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(judul, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('Penulis: $penulis', style: const TextStyle(fontSize: 16)),
            Text('Kategori: $kategori', style: const TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 10),
            Text('Harga: Rp$harga', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
            const SizedBox(height: 20),
            const Text('Deskripsi Buku:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(deskripsi),
            const SizedBox(height: 100),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, -2)),
          ],
        ),
        child: Row(
          children: [
            // Tombol Wishlist
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  final exists = wishlist.any((item) => item['judul'] == judul);
                  if (!exists) {
                    wishlist.add({
                      'judul': judul,
                      'harga': harga,
                      'foto': foto,
                      'penulis': penulis,
                      'deskripsi': deskripsi,
                      'kategori': kategori,
                    });

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Buku "$judul" ditambahkan ke wishlist.')),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Buku "$judul" sudah ada di wishlist.')),
                    );
                  }
                },
                icon: const Icon(Icons.favorite_border),
                label: const Text("Wishlist"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.blue[900],
                  side: BorderSide(color: Colors.blue[900]!),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),

            const SizedBox(width: 12),

            // Tombol Keranjang
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  final index = keranjang.indexWhere((item) => item['judul'] == judul);
                  if (index != -1) {
                    keranjang[index]['jumlah'] += 1;
                  } else {
                    keranjang.add({
                      'judul': judul,
                      'harga': harga,
                      'foto': foto,
                      'jumlah': 1,
                    });
                  }

                  onAddToCart(); // Notifikasi badge di icon keranjang
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Buku "$judul" ditambahkan ke keranjang.')),
                  );
                },
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('Keranjang'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[900],
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
