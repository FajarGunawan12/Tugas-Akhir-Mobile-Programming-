import 'package:flutter/material.dart';
import './search_field.dart';
import './buku_list.dart';
import './buku_cart.dart';
import '../keranjang/keranjang_page.dart';

class BerandaPage extends StatefulWidget {
  final ValueNotifier<int> cartNotifier;
  final Map<String, dynamic> userData; // ✅ Tambahkan ini

  const BerandaPage({
    super.key,
    required this.cartNotifier,
    required this.userData, // ✅ Tambahkan ini
  });

  @override
  State<BerandaPage> createState() => _BerandaPageState();
}

class _BerandaPageState extends State<BerandaPage> {
  String searchText = '';
  String selectedKategori = '';

  @override
  Widget build(BuildContext context) {
    final filteredBooks = bukuList.where((buku) {
      final judul = buku['judul'].toString().toLowerCase();
      final kategori = buku['kategori'].toString().toLowerCase();
      return judul.contains(searchText.toLowerCase()) &&
          (selectedKategori.isEmpty || kategori == selectedKategori.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        title: SearchField(
          onChanged: (value) {
            setState(() {
              searchText = value;
            });
          },
        ),
        actions: [
          ValueListenableBuilder<int>(
            valueListenable: widget.cartNotifier,
            builder: (context, cartCount, _) {
              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => KeranjangPage(
                            userData: widget.userData, // ✅ Kirim data user ke keranjang
                          ),
                        ),
                      );
                    },
                  ),
                  if (cartCount > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '$cartCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _kategoriPopulerSection(),
                const SizedBox(height: 16),
                const Text(
                  "Daftar Buku",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12.0,
                    mainAxisSpacing: 12.0,
                    mainAxisExtent: 280,
                  ),
                  itemCount: filteredBooks.length,
                  itemBuilder: (_, index) {
                    final buku = filteredBooks[index];
                    return BukuCart(
                      judul: buku['judul'],
                      harga: buku['harga'],
                      foto: buku['foto'],
                      penulis: buku['penulis'],
                      deskripsi: buku['deskripsi'],
                      kategori: buku['kategori'],
                      onAddToCart: () {
                        widget.cartNotifier.value++;
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _kategoriPopulerSection() {
    final kategoriList = ['Novel', 'Komik', 'Teknologi', 'Bisnis', 'Anak-anak'];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Kategori Populer",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 40,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: kategoriList.length,
            itemBuilder: (context, index) {
              final kategori = kategoriList[index];
              final isSelected = selectedKategori == kategori;

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedKategori = isSelected ? '' : kategori;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.blue[700] : Colors.blue[100],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text(
                      kategori,
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
