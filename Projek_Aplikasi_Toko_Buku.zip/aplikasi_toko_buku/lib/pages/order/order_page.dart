import 'package:flutter/material.dart';
import 'order_detail_page.dart'; // Pastikan file ini sudah dibuat

class OrderPage extends StatelessWidget {
  final List<Map<String, dynamic>> orders;

  const OrderPage({super.key, required this.orders});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pesanan Anda'),
        backgroundColor: Colors.blue[900],
      ),
      body: orders.isEmpty
          ? const Center(child: Text("Belum ada pesanan"))
          : ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                final order = orders[index];
                final List<dynamic> items = order['items'] ?? [];
                final String judulBuku = items.map((b) => b['judul']).join(', ');

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.receipt_long_rounded),
                    title: Text("Rp ${order['total']}"),
                    subtitle: Text("Buku: $judulBuku\nMetode: ${order['metode']}"),
                    isThreeLine: true,
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrderDetailPage(order: order),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
