import 'package:flutter/material.dart';
import './tombol_register.dart';
import './tombol_login.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Gambar Welcome
              Image.asset(
                'assets/img/poi.png',
                width: screenWidth * 0.7,
              ),

              // Judul
              Text(
                "Selamat Datang di Pustaka Digital",
                style: TextStyle(
                  fontSize: screenWidth * 0.07,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueAccent,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 20),

              // Deskripsi
              Text(
                "Temukan dan beli berbagai buku favoritmu hanya dalam satu aplikasi. Mudah, cepat, dan praktis.",
                style: TextStyle(
                  fontSize: screenWidth * 0.045,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 20),

              // Tombol Register dan Login
              const TombolRegister(),
              const SizedBox(height: 16),
              const TombolLogin(),
            ],
          ),
        ),
      ),
    );
  }
}
