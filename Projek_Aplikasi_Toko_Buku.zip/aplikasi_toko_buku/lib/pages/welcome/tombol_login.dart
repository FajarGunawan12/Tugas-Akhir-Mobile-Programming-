import 'package:flutter/material.dart';
import '../login/login_page.dart';

/// TombolLogin digunakan di halaman WelcomePage.
/// Ketika ditekan, tombol ini akan menavigasi pengguna ke halaman LoginPage.
class TombolLogin extends StatelessWidget {
  const TombolLogin({super.key});

  @override
  Widget build(BuildContext context) {
    final double buttonWidth = MediaQuery.of(context).size.width - 2 * 24;

    return Container(
      height: 60,
      width: buttonWidth,
      child: ElevatedButton(
        onPressed: () {
          // Navigasi ke halaman login
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          );
        },
        child: const Text(
          "Login", // Ubah agar tidak membingungkan dengan tombol login yang sebenarnya
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w500,
            color: Colors.blueAccent,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: const BorderSide(color: Colors.blueAccent, width: 3),
          ),
          elevation: 3,
        ),
      ),
    );
  }
}
