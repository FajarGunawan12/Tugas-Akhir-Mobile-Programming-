// lib/notifiers/cart_notifier.dart
import 'package:flutter/material.dart';

class CartNotifier extends ValueNotifier<int> {
  CartNotifier() : super(0);

  void addItem() => value++;
  void removeItem() => value = value > 0 ? value - 1 : 0;
  void clearCart() => value = 0;
}
