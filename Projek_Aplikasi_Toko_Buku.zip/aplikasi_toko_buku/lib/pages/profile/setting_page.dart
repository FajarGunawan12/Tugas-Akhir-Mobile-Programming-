import 'package:flutter/material.dart';
import 'ubah_password.dart';
import '../../main.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _notifikasiAktif = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pengaturan")),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text("Notifikasi"),
            value: _notifikasiAktif,
            onChanged: (val) {
              setState(() {
                _notifikasiAktif = val;
              });
            },
          ),
          SwitchListTile(
            title: const Text("Mode Gelap"),
            subtitle: const Text("Ubah tampilan ke dark mode"),
            value: themeNotifier.value == ThemeMode.dark,
            onChanged: (value) {
              setState(() {
                themeNotifier.value = value ? ThemeMode.dark : ThemeMode.light;
              });
            },
          ),
          ListTile(
            leading: const Icon(Icons.lock),
            title: const Text("Ubah Password"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const UbahPasswordPage(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
