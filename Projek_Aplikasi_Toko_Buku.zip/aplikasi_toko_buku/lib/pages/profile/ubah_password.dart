import 'package:flutter/material.dart';

class UbahPasswordPage extends StatefulWidget {
  const UbahPasswordPage({super.key});

  @override
  State<UbahPasswordPage> createState() => _UbahPasswordPageState();
}

class _UbahPasswordPageState extends State<UbahPasswordPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _passwordBaruController = TextEditingController();
  final TextEditingController _konfirmasiPasswordController = TextEditingController();

  @override
  void dispose() {
    _passwordBaruController.dispose();
    _konfirmasiPasswordController.dispose();
    super.dispose();
  }

  void _simpanPassword() {
    if (_formKey.currentState!.validate()) {
      // Simulasi berhasil ubah password
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("Berhasil"),
          content: const Text("Password berhasil diubah (simulasi)."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), 
              child: const Text("OK"),
            )
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ubah Password")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _passwordBaruController,
                obscureText: true,
                decoration: const InputDecoration(labelText: "Password Baru"),
                validator: (value) {
                  if (value == null || value.length < 6) {
                    return "Password minimal 6 karakter";
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _konfirmasiPasswordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: "Konfirmasi Password"),
                validator: (value) {
                  if (value != _passwordBaruController.text) {
                    return "Password tidak cocok";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _simpanPassword,
                child: const Text("Simpan Password"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
