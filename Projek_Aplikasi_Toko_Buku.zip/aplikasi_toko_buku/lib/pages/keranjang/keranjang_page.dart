import 'package:flutter/material.dart';
import '../keranjang/keranjang_data.dart';
import '../checkout/checkout_page.dart';

class KeranjangPage extends StatefulWidget {
  final Map<String, dynamic> userData; // ✅ Tambahkan ini

  const KeranjangPage({super.key, required this.userData}); // ✅ Tambahkan required

  @override
  State<KeranjangPage> createState() => _KeranjangPageState();
}

class _KeranjangPageState extends State<KeranjangPage> {
  @override
  Widget build(BuildContext context) {
    final total = keranjang.fold<double>(
      0,
      (sum, item) => sum + (item['harga'] as int) * (item['jumlah'] as int),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Keranjang'),
        backgroundColor: Colors.blue[900],
      ),
      body: keranjang.isEmpty
          ? const Center(child: Text('Keranjang masih kosong.'))
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: ListView.builder(
                itemCount: keranjang.length,
                itemBuilder: (context, index) {
                  final item = keranjang[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: Image.asset(
                        item['foto'],
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                      title: Text(item['judul']),
                      subtitle: Text(
                        'Rp ${item['harga']} x ${item['jumlah']} = Rp ${(item['harga'] as int) * (item['jumlah'] as int)}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          setState(() {
                            keranjang.removeAt(index);
                          });
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
      bottomNavigationBar: keranjang.isNotEmpty
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total: Rp $total',
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CheckoutPage(
                            totalBayar: total.toInt(),
                            items: List<Map<String, dynamic>>.from(keranjang),
                            userData: widget.userData, // ✅ Penting
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      backgroundColor: Colors.blue[900],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text(
                      'Checkout',
                      style: TextStyle(fontSize: 16,color: Colors.white),
                    ),
                  ),
                ],
              ),
            )
          : null,
    );
  }
}
