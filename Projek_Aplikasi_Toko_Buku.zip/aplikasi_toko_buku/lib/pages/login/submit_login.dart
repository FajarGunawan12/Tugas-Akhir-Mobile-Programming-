import 'package:flutter/material.dart';

/// SubmitLogin adalah tombol utama untuk mengirim data login.
/// Tombol ini dipakai di halaman LoginPage dan menjalankan fungsi onPressed.
class SubmitLogin extends StatelessWidget {
  final VoidCallback onPressed;

  const SubmitLogin({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final double buttonWidth = MediaQuery.of(context).size.width - 2 * 24;

    return Container(
      height: 60,
      width: buttonWidth,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue[900],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          elevation: 3,
        ),
        child: const Text(
          "Login Sekarang", // Ganti agar tidak membingungkan dengan tombol navigasi login
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
